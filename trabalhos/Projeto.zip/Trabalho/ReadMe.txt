+--------------------------------------------------------------------+
|                                                                    |
|   SISTEMA DE CONTROLE E ESTATÍSTICAS DE DADOS IMOBILIÁRIOS         |
|                                                                    |
+--------------------------------------------------------------------+
|   Autor: Gabriel Henrique Silva Pereira                            |
|   RA: 2025.1.08.036                                                |
|   Autor: Otávio de Oliveira                                        |
|   RA: 2025.1.08.034                                                |
+--------------------------------------------------------------------+

// 1. SOBRE O PROJETO //

Este aplicativo, desenvolvido em C++, é um sistema para o gerenciamento de uma base de dados de imóveis. O projeto foi criado para aplicar conceitos de programação como a manipulação de registros (structs) em vetores, entrada e saída de arquivos, e a geração de relatórios estatísticos simples.

O programa interage com um arquivo de texto (`BD_Imoveis2.txt`), lendo os dados na inicialização e salvando todas as alterações realizadas ao ser encerrado.

» Principais Características:
  • Gerenciamento completo de imóveis via menu interativo.
  • Leitura e gravação automática dos dados em arquivo.
  • Manutenção de um vetor de dados sempre contíguo (sem "buracos" após exclusões).
  • Capacidade para armazenar até 200 registros de imóveis.
  • Geração de relatórios estatísticos sobre a base de dados.

======================================================================

// 2. FUNCIONALIDADES DO MENU //

O sistema é operado através de um menu principal que oferece as seguintes opções:

  • Cadastrar Imóvel: Adiciona um novo registro de imóvel à base.
  • Listar Todos os Imóveis: Exibe todos os imóveis cadastrados.
  • Pesquisar Imóvel: Busca por imóveis com base em critérios específicos.
  • Excluir Imóvel: Remove um registro da base de dados.
  • Gerar Relatórios: Apresenta estatísticas sobre os imóveis (ex: valor médio por bairro, etc.).
  • Salvar e Sair: Grava todas as alterações no arquivo `BD_Imoveis2.txt` e encerra o programa.

======================================================================

// 3. ESTRUTURA DO ARQUIVO DE DADOS (BD_Imoveis2.txt) //

O arquivo que serve como banco de dados (`BD_Imoveis2.txt`) é um texto simples com um formato específico que deve ser respeitado.

  • A primeira linha do arquivo é um cabeçalho e será ignorada pelo programa.
  • Cada linha seguinte representa UM imóvel com 22 campos separados por espaço.
  • A última linha do arquivo DEVE conter apenas a palavra `fim` para sinalizar o término dos dados.

  [ Formato dos 22 Campos ]
  tipo finalidade endereco bairro cidade area valor iptu quartos suites banheiros vagas cozinha sala varanda areaServico piso conservacao armarios arCondicionado aquecedor ventilador

  [ Exemplo de linha VÁLIDA ]
  casa venda Rua_das_Flores,123 Centro Campinas 150.5 550000 1200 3 1 2 2 sim sim nao sim porcelanato novo sim nao nao sim

  [ IMPORTANTE ]
  » Para campos de característica (cozinha, sala, etc.), use "sim" ou "nao".
  » Nomes compostos (endereços, tipos de imóvel) não devem conter espaços. Use sublinhado `_` ou junte as palavras (ex: `Rua_das_Flores` ou `Sala_Comercial`).

======================================================================

// 4. OBSERVAÇÕES //

  • Caso o arquivo `BD_Imoveis2.txt` não seja encontrado na inicialização, o sistema iniciará com uma base de dados vazia. Ao sair, um novo arquivo será criado.
  • O limite máximo de 200 imóveis é definido por uma constante no código-fonte.
